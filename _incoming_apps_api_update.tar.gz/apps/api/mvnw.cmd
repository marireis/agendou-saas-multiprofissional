@ECHO OFF
REM Maven Wrapper para Windows. Ver .mvn/wrapper/mvnw.ps1 para a logica de
REM download/extracao e o motivo deste wrapper ser escrito a mao.
SETLOCAL

SET WRAPPER_DIR=%~dp0
powershell -NoProfile -ExecutionPolicy Bypass -File "%WRAPPER_DIR%.mvn\wrapper\mvnw.ps1" %*
SET MVNW_EXIT_CODE=%ERRORLEVEL%

ENDLOCAL & EXIT /B %MVNW_EXIT_CODE%
