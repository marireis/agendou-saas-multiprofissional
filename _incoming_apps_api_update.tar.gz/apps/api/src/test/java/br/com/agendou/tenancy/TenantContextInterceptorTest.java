package br.com.agendou.tenancy;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.HandlerMapping;

class TenantContextInterceptorTest {
    private final TenantContextInterceptor interceptor = new TenantContextInterceptor();

    @AfterEach
    void clearAnyLeftoverContext() {
        TenantContext.clear();
    }

    @Test
    void populatesTenantContextFromPathVariable() {
        UUID tenantId = UUID.randomUUID();
        MockHttpServletRequest request = requestWithTenantPathVariable(tenantId.toString());

        interceptor.preHandle(request, new MockHttpServletResponse(), new Object());

        assertThat(TenantContext.current()).contains(tenantId);
    }

    @Test
    void clearsTenantContextAfterRequestCompletes() {
        UUID tenantId = UUID.randomUUID();
        MockHttpServletRequest request = requestWithTenantPathVariable(tenantId.toString());

        interceptor.preHandle(request, new MockHttpServletResponse(), new Object());
        assertThat(TenantContext.current()).isPresent();

        interceptor.afterCompletion(request, new MockHttpServletResponse(), new Object(), null);

        // Critico: threads de servidor sao reaproveitadas por um pool: se
        // isto nao limpar, a proxima requisicao processada pela mesma
        // thread herdaria o tenant desta.
        assertThat(TenantContext.current()).isEmpty();
    }

    @Test
    void rejectsPathVariableThatIsNotAValidUuid() {
        MockHttpServletRequest request = requestWithTenantPathVariable("nao-e-um-uuid");

        assertThatThrownBy(() -> interceptor.preHandle(request, new MockHttpServletResponse(), new Object()))
            .isInstanceOf(ResponseStatusException.class);
    }

    @Test
    void leavesTenantContextEmptyWhenRouteHasNoTenantIdVariable() {
        MockHttpServletRequest request = new MockHttpServletRequest();

        interceptor.preHandle(request, new MockHttpServletResponse(), new Object());

        assertThat(TenantContext.current()).isEmpty();
    }

    private static MockHttpServletRequest requestWithTenantPathVariable(String tenantId) {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setAttribute(
            HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE,
            Map.of("tenantId", tenantId)
        );
        return request;
    }
}
