package br.com.agendou.web;

import br.com.agendou.tenancy.TenantMismatchException;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Tratamento minimo de erros para as excecoes introduzidas junto com o
 * isolamento por tenant. Nao substitui um tratamento de erros completo
 * (ver docs/api-contract.md secao 1) — esse fica para quando as demais
 * excecoes de dominio (assinatura nao encontrada, etc.) forem revisadas.
 */
@RestControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(TenantMismatchException.class)
    public ResponseEntity<ApiErrorResponse> handleTenantMismatch(TenantMismatchException ex) {
        ApiErrorResponse body = new ApiErrorResponse(
            "TENANT_MISMATCH",
            "Nao autorizado para o tenant solicitado.",
            UUID.randomUUID().toString()
        );
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(body);
    }
}
