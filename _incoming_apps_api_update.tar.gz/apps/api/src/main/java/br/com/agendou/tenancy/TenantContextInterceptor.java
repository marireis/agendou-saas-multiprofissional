package br.com.agendou.tenancy;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Map;
import java.util.UUID;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.HandlerMapping;

/**
 * Extrai o {@code tenantId} da variavel de path da rota (ex.:
 * {@code /api/v1/subscriptions/{tenantId}}) e popula o {@link TenantContext}
 * para a duracao da requisicao.
 *
 * <p><b>Limitacao atual, documentada de proposito:</b> ate a autenticacao
 * admin (MVP-011) e o filtro de membership (MVP-013 completo) existirem,
 * este interceptor confia no tenantId do path sem confirmar que quem faz a
 * requisicao realmente pertence aquele tenant. Isso e diferente de confiar
 * em tenantId no corpo (o que as sdd-rules proibem) e e suficiente para
 * isolar dados no banco via RLS + set_config, mas NAO substitui
 * autorizacao. Nenhuma rota fica protegida contra um chamador que apenas
 * "adivinha" o UUID de outro tenant enquanto a autenticacao nao existir.</p>
 */
@Component
public class TenantContextInterceptor implements HandlerInterceptor {
    private static final String TENANT_PATH_VARIABLE = "tenantId";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        Object attribute = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        if (!(attribute instanceof Map<?, ?> pathVariables)) {
            return true;
        }

        Object rawTenantId = pathVariables.get(TENANT_PATH_VARIABLE);
        if (rawTenantId == null) {
            return true;
        }

        try {
            TenantContext.set(UUID.fromString(rawTenantId.toString()));
        } catch (IllegalArgumentException ex) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "tenantId invalido.");
        }

        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        TenantContext.clear();
    }
}
