package br.com.agendou.billing;

import java.time.Clock;
import java.time.Duration;
import java.util.UUID;
import org.springframework.stereotype.Service;

@Service
public class SubscriptionService {
    private final SubscriptionRepository repository;
    private final TrialPolicy trialPolicy;
    private final Clock clock;

    public SubscriptionService(SubscriptionRepository repository) {
        this.repository = repository;
        this.clock = Clock.systemUTC();
        this.trialPolicy = new TrialPolicy(clock);
    }

    public Subscription startPremiumTrial(UUID tenantId) {
        repository.findByTenantId(tenantId).ifPresent(existing -> {
            throw new IllegalStateException("Tenant ja possui assinatura registrada.");
        });
        return repository.save(trialPolicy.startTrial(tenantId, PlanCode.PREMIUM_TOP));
    }

    public Subscription current(UUID tenantId) {
        Subscription subscription = repository.findByTenantId(tenantId)
            .orElseThrow(() -> new IllegalArgumentException("Assinatura nao encontrada."));
        return repository.save(trialPolicy.refreshStatus(subscription));
    }

    public Subscription confirmPayment(UUID tenantId) {
        Subscription subscription = current(tenantId);
        return repository.save(subscription.paidUntil(clock.instant().plus(Duration.ofDays(30))));
    }
}
