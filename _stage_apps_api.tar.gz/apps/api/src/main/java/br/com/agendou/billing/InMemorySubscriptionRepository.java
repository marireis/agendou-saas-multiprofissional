package br.com.agendou.billing;

import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Repository;

@Repository
public class InMemorySubscriptionRepository implements SubscriptionRepository {
    private final ConcurrentHashMap<UUID, Subscription> subscriptions = new ConcurrentHashMap<>();

    @Override
    public Subscription save(Subscription subscription) {
        subscriptions.put(subscription.tenantId(), subscription);
        return subscription;
    }

    @Override
    public Optional<Subscription> findByTenantId(UUID tenantId) {
        return Optional.ofNullable(subscriptions.get(tenantId));
    }
}
