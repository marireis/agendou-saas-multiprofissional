package br.com.agendou.billing;

import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/subscriptions")
public class SubscriptionController {
    private final SubscriptionService service;

    public SubscriptionController(SubscriptionService service) {
        this.service = service;
    }

    @PostMapping("/{tenantId}/trial")
    @ResponseStatus(HttpStatus.CREATED)
    public Subscription startTrial(@PathVariable UUID tenantId) {
        return service.startPremiumTrial(tenantId);
    }

    @GetMapping("/{tenantId}")
    public Subscription current(@PathVariable UUID tenantId) {
        return service.current(tenantId);
    }

    @PostMapping("/{tenantId}/confirm-payment")
    public Subscription confirmPayment(@PathVariable UUID tenantId) {
        return service.confirmPayment(tenantId);
    }
}
